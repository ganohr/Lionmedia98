      <div class="searchBox">
        <form class="searchBox__form" method="get" target="_top" action="<?php echo home_url( '/' ); ?>" >
          <input class="searchBox__input" type="text" maxlength="50" name="s" placeholder="記事検索"><button class="searchBox__submit icon-search" type="submit" value="search"> </button>
        </form>
      </div>