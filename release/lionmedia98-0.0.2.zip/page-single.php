<?php /* Template Name:シングルカラムTPL */?>
<?php get_header(); ?>
<?php fit_breadcrumb(); ?>

  <!-- l-wrapper -->
  <div class="l-wrapper">

	<!-- l-main -->
	<main class="l-main l-main-single<?php if ( get_option('fit_theme_singleWidth') == 'value2' ):?> l-main-w740<?php endif; ?>
	<?php if ( get_option('fit_theme_singleWidth') == 'value3' ):?> l-main-w900<?php endif; ?>
	<?php if ( get_option('fit_theme_singleWidth') == 'value4' ):?> l-main-w100<?php endif; ?>">

	  <article>
	  <h1 class="heading heading-page"><?php the_title(); ?></h1>

	  <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	  <section class="content content-page" data-clarity-region="article">
		<?php the_content(); ?>
		<?php get_template_part('pager-page-links'); ?>
	  </section>
	  <?php endwhile; endif; ?>

	  </article>


	</main>
	<!-- /l-main -->

  </div>
  <!-- /l-wrapper -->

<?php get_footer(); ?>